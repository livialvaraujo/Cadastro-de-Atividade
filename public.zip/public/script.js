// Configuração do Firebase (substitua com suas credenciais)
const firebaseConfig = {
    apiKey: "SUA_API_KEY",
    authDomain: "SEU_PROJETO.firebaseapp.com",
    projectId: "SEU_PROJETO",
    storageBucket: "SEU_PROJETO.appspot.com",
    messagingSenderId: "SEU_SENDER_ID",
    appId: "SEU_APP_ID"
};

// Inicialize o Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Função para carregar atividades do Firestore
async function carregarAtividades() {
    try {
        const querySnapshot = await db.collection("atividades").get();
        const tabela = document.getElementById('tabelaAtividades');
        tabela.innerHTML = '';

        querySnapshot.forEach((doc) => {
            const atividade = doc.data();
            const novaLinha = tabela.insertRow();

            novaLinha.insertCell(0).textContent = atividade.descricao;
            novaLinha.insertCell(1).textContent = atividade.categoria;
            novaLinha.insertCell(2).textContent = atividade.tipo_especifico;
            novaLinha.insertCell(3).textContent = atividade.horas;

            const celulaAcao = novaLinha.insertCell(4);
            const botaoExcluir = document.createElement('button');
            botaoExcluir.textContent = 'Excluir';
            botaoExcluir.className = 'btn-excluir';
            botaoExcluir.onclick = () => excluirAtividade(doc.id);
            celulaAcao.appendChild(botaoExcluir);
        });
    } catch (error) {
        console.error('Erro ao carregar atividades:', error);
    }
}

// Função para salvar uma nova atividade no Firestore
async function salvarAtividade(atividade) {
    try {
        await db.collection("atividades").add(atividade);
        carregarAtividades();
    } catch (error) {
        console.error('Erro ao salvar atividade:', error);
    }
}

// Função para excluir uma atividade do Firestore
async function excluirAtividade(id) {
    try {
        await db.collection("atividades").doc(id).delete();
        carregarAtividades();
    } catch (error) {
        console.error('Erro ao excluir atividade:', error);
    }
}

// Evento de submit do formulário
document.getElementById('formCadastro').addEventListener('submit', async function (event) {
    event.preventDefault();
    const descricao = document.getElementById('descricao').value;
    const categoria = document.getElementById('categoria').value;
    const tipo_especifico = document.getElementById('tipo_especifico').value;
    const horas = document.getElementById('horas').value;

    const novaAtividade = { descricao, categoria, tipo_especifico, horas };
    await salvarAtividade(novaAtividade);
    document.getElementById('formCadastro').reset();
});

// Carregar atividades ao carregar a página
window.onload = carregarAtividades;